const express = require('express');
const app = express();
app.get('/', (req, res) => res.json({ message: 'Express API' }));
app.listen(3000, () => console.log('Listening on 3000'));
