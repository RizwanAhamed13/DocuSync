# Express REST API

Run with: npm install && npm start
