# React + Vite + Tailwind

Run with: npm install && npm run dev
